package thread.WaitNotify;

public class valueObject {
    public static String value ="";
}
